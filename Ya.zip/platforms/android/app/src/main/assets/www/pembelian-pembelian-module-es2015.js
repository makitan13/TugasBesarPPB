(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pembelian-pembelian-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pembelian/pembelian.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pembelian/pembelian.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n  <ion-buttons slot=\"start\">\n  <ion-back-button defaultHref=\"cart\"></ion-back-button>\n  </ion-buttons>\n  <ion-title>Pembelian</ion-title>\n  </ion-toolbar>\n </ion-header>\n <ion-content class=\"ion-padding\" color=\"secondary\">\n  <ion-item>\n  <ion-label position=\"stacked\">Nama</ion-label>\n  <ion-input [(ngModel)]=\"dataPembeli.nama\"></ion-input>\n  </ion-item>\n  <ion-item>\n  <ion-label position=\"stacked\">Alamat</ion-label>\n  <ion-input [(ngModel)]=\"dataPembeli.alamat\"></ion-input>\n  </ion-item>\n  <ion-button (click)=\"pembayaran()\" expand=\"block\" color=\"tertiary\">Pembayaran</ion-button>\n </ion-content>"

/***/ }),

/***/ "./src/app/pembelian/pembelian-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pembelian/pembelian-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: PembelianPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PembelianPageRoutingModule", function() { return PembelianPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _pembelian_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pembelian.page */ "./src/app/pembelian/pembelian.page.ts");




const routes = [
    {
        path: '',
        component: _pembelian_page__WEBPACK_IMPORTED_MODULE_3__["PembelianPage"]
    }
];
let PembelianPageRoutingModule = class PembelianPageRoutingModule {
};
PembelianPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PembelianPageRoutingModule);



/***/ }),

/***/ "./src/app/pembelian/pembelian.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pembelian/pembelian.module.ts ***!
  \***********************************************/
/*! exports provided: PembelianPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PembelianPageModule", function() { return PembelianPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pembelian_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pembelian-routing.module */ "./src/app/pembelian/pembelian-routing.module.ts");
/* harmony import */ var _pembelian_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pembelian.page */ "./src/app/pembelian/pembelian.page.ts");







let PembelianPageModule = class PembelianPageModule {
};
PembelianPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _pembelian_routing_module__WEBPACK_IMPORTED_MODULE_5__["PembelianPageRoutingModule"]
        ],
        declarations: [_pembelian_page__WEBPACK_IMPORTED_MODULE_6__["PembelianPage"]]
    })
], PembelianPageModule);



/***/ }),

/***/ "./src/app/pembelian/pembelian.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pembelian/pembelian.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BlbWJlbGlhbi9wZW1iZWxpYW4ucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pembelian/pembelian.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pembelian/pembelian.page.ts ***!
  \*********************************************/
/*! exports provided: PembelianPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PembelianPage", function() { return PembelianPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_cart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/cart.service */ "./src/app/services/cart.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/utils.service */ "./src/app/services/utils.service.ts");





let PembelianPage = class PembelianPage {
    constructor(router, utils, cart) {
        this.router = router;
        this.utils = utils;
        this.cart = cart;
        this.dataPembeli = {
            nama: '',
            alamat: ''
        };
    }
    ngOnInit() {
    }
    pembayaran() {
        console.log(this.dataPembeli);
        this.cart.clearCart();
        this.utils.showToast('Data telah disimpan');
        this.router.navigate(['/home']);
    }
};
PembelianPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"] },
    { type: _services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"] }
];
PembelianPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pembelian',
        template: __webpack_require__(/*! raw-loader!./pembelian.page.html */ "./node_modules/raw-loader/index.js!./src/app/pembelian/pembelian.page.html"),
        styles: [__webpack_require__(/*! ./pembelian.page.scss */ "./src/app/pembelian/pembelian.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["UtilsService"],
        _services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"]])
], PembelianPage);



/***/ })

}]);
//# sourceMappingURL=pembelian-pembelian-module-es2015.js.map